// FILE PATH: app/src/main/java/com/example/budgettracker/ReportsActivity.java

package com.example.budgettracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportsActivity extends AppCompatActivity {

    TextView tvBudget, tvSpent, tvSaved, tvStatus;
    ListView lvCategoryReport;
    Button btnBack;
    DatabaseHelper db;
    int currentUserId; // ← Ye naya add kiya

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        db = new DatabaseHelper(this);

        // SharedPreferences se userId lo
        SharedPreferences prefs = getSharedPreferences("BudgetApp", MODE_PRIVATE);
        currentUserId = prefs.getInt("userId", -1); // ← Ye naya add kiya

        tvBudget         = findViewById(R.id.tvReportBudget);
        tvSpent          = findViewById(R.id.tvReportSpent);
        tvSaved          = findViewById(R.id.tvReportSaved);
        tvStatus         = findViewById(R.id.tvReportStatus);
        lvCategoryReport = findViewById(R.id.lvCategoryReport);
        btnBack          = findViewById(R.id.btnBackReport);

        loadReport();

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadReport() {

        // ← Har jagah currentUserId pass kiya
        double budget = db.getBudget(currentUserId);
        double spent  = db.getTotalExpenses(currentUserId);
        double saved  = budget - spent;

        tvBudget.setText("Budget:  ₹" + String.format("%.0f", budget));
        tvSpent.setText("Spent:   ₹" + String.format("%.0f", spent));
        tvSaved.setText("Saved:   ₹" + String.format("%.0f", Math.max(saved, 0)));

        if (budget == 0) {
            tvStatus.setText("No budget set");
        } else if (spent > budget) {
            tvStatus.setText("⚠ Budget Exceeded by ₹"
                    + String.format("%.0f", spent - budget));
        } else {
            double percent = (spent / budget) * 100;
            tvStatus.setText("✔ " + String.format("%.0f", percent)
                    + "% of budget used");
        }

        // ← Yahan bhi currentUserId pass kiya
        List<Expense> expenses = db.getAllExpenses(currentUserId);
        Map<String, Double> categoryMap = new HashMap<>();

        for (Expense e : expenses) {
            String cat = e.getCategory();
            categoryMap.put(cat,
                    categoryMap.getOrDefault(cat, 0.0) + e.getAmount());
        }

        List<String> reportList = new ArrayList<>();
        for (Map.Entry<String, Double> entry : categoryMap.entrySet()) {
            reportList.add(entry.getKey() + "  →  ₹"
                    + String.format("%.0f", entry.getValue()));
        }

        if (reportList.isEmpty()) {
            reportList.add("No expenses recorded yet");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, reportList);
        lvCategoryReport.setAdapter(adapter);
    }
}