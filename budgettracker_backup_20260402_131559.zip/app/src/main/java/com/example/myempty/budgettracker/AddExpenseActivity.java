// FILE PATH: app/src/main/java/com/example/budgettracker/AddExpenseActivity.java

package com.example.budgettracker;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.*;

public class AddExpenseActivity extends AppCompatActivity {

    EditText etAmount, etDate, etNote;
    Spinner spCategory;
    Button btnSave, btnCancel;
    DatabaseHelper db;
    int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        db = new DatabaseHelper(this);
        currentUserId = getIntent().getIntExtra("userId", -1);

        etAmount   = findViewById(R.id.etAmount);
        etDate     = findViewById(R.id.etDate);
        etNote     = findViewById(R.id.etNote);
        spCategory = findViewById(R.id.spCategory);
        btnSave    = findViewById(R.id.btnSave);
        btnCancel  = findViewById(R.id.btnCancel);

        String today = new SimpleDateFormat("dd/MM/yyyy",
                Locale.getDefault()).format(new Date());
        etDate.setText(today);

        String[] categories = {"Food","Travel","Shopping",
                "Bills","Health","Education","Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, categories);
        spCategory.setAdapter(adapter);

        btnSave.setOnClickListener(v -> saveExpense());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void saveExpense() {
        String amountStr = etAmount.getText().toString().trim();
        String category  = spCategory.getSelectedItem().toString();
        String date      = etDate.getText().toString().trim();
        String note      = etNote.getText().toString().trim();

        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter amount",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        double amount = Double.parseDouble(amountStr);
        // User ID ke sath save karo
        boolean result = db.addExpense(amount, category, date,
                note, currentUserId);

        if (result) {
            Toast.makeText(this, "Expense saved!",
                    Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error saving expense",
                    Toast.LENGTH_SHORT).show();
        }
    }
}