// FILE PATH: app/src/main/java/com/example/budgettracker/DatabaseHelper.java

package com.example.budgettracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BudgetTracker.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_NAME = "name";
    public static final String COL_EMAIL = "email";
    public static final String COL_PASSWORD = "password";

    public static final String TABLE_EXPENSES = "expenses";
    public static final String COL_EXPENSE_ID = "expense_id";
    public static final String COL_AMOUNT = "amount";
    public static final String COL_CATEGORY = "category";
    public static final String COL_DATE = "date";
    public static final String COL_NOTE = "note";
    public static final String COL_OWNER_ID = "owner_id"; // NEW

    public static final String TABLE_BUDGET = "budget";
    public static final String COL_BUDGET_ID = "budget_id";
    public static final String COL_MONTHLY_LIMIT = "monthly_limit";
    public static final String COL_BUDGET_OWNER_ID = "owner_id"; // NEW

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_NAME + " TEXT, "
                + COL_EMAIL + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_EXPENSES + " ("
                + COL_EXPENSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_AMOUNT + " REAL, "
                + COL_CATEGORY + " TEXT, "
                + COL_DATE + " TEXT, "
                + COL_NOTE + " TEXT, "
                + COL_OWNER_ID + " INTEGER)"); // NEW

        db.execSQL("CREATE TABLE " + TABLE_BUDGET + " ("
                + COL_BUDGET_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_MONTHLY_LIMIT + " REAL, "
                + COL_BUDGET_OWNER_ID + " INTEGER)"); // NEW
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_BUDGET);
        onCreate(db);
    }

    // ── USER METHODS ──────────────────────────────

    public boolean registerUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NAME, name);
        values.put(COL_EMAIL, email);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public int loginUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_EMAIL + "=? AND " + COL_PASSWORD + "=?",
                new String[]{email, password}, null, null, null);
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            return id; // Return user ID
        }
        cursor.close();
        return -1; // Login failed
    }

    // ── EXPENSE METHODS ───────────────────────────

    public boolean addExpense(double amount, String category,
                              String date, String note, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_AMOUNT, amount);
        values.put(COL_CATEGORY, category);
        values.put(COL_DATE, date);
        values.put(COL_NOTE, note);
        values.put(COL_OWNER_ID, userId); // Save with user ID
        long result = db.insert(TABLE_EXPENSES, null, values);
        return result != -1;
    }

    public List<Expense> getAllExpenses(int userId) {
        List<Expense> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_EXPENSES +
                " WHERE " + COL_OWNER_ID + "=?" +
                " ORDER BY " + COL_DATE + " DESC",
                new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            do {
                list.add(new Expense(
                        cursor.getInt(0),
                        cursor.getDouble(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return list;
    }

    public double getTotalExpenses(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT SUM(" + COL_AMOUNT + ") FROM " + TABLE_EXPENSES +
                " WHERE " + COL_OWNER_ID + "=?",
                new String[]{String.valueOf(userId)});
        double total = 0;
        if (cursor.moveToFirst()) total = cursor.getDouble(0);
        cursor.close();
        return total;
    }

    // ── BUDGET METHODS ────────────────────────────

    public boolean setBudget(double limit, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_BUDGET, COL_BUDGET_OWNER_ID + "=?",
                new String[]{String.valueOf(userId)});
        ContentValues values = new ContentValues();
        values.put(COL_MONTHLY_LIMIT, limit);
        values.put(COL_BUDGET_OWNER_ID, userId);
        long result = db.insert(TABLE_BUDGET, null, values);
        return result != -1;
    }

    public double getBudget(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + COL_MONTHLY_LIMIT + " FROM " + TABLE_BUDGET +
                " WHERE " + COL_BUDGET_OWNER_ID + "=?",
                new String[]{String.valueOf(userId)});
        double budget = 0;
        if (cursor.moveToFirst()) budget = cursor.getDouble(0);
        cursor.close();
        return budget;
    }
}