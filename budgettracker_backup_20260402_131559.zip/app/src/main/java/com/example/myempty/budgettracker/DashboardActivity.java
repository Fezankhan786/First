// FILE PATH: app/src/main/java/com/example/budgettracker/DashboardActivity.java

package com.example.budgettracker;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    TextView tvBalance, tvBudget, tvSpent;
    Button btnAddExpense, btnSetBudget, btnReports, btnLogout;
    ListView lvExpenses;
    DatabaseHelper db;
    int currentUserId; // Current logged in user

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        // User ID lo SharedPreferences se
        SharedPreferences prefs = getSharedPreferences("BudgetApp", MODE_PRIVATE);
        currentUserId = prefs.getInt("userId", -1);

        tvBalance     = findViewById(R.id.tvBalance);
        tvBudget      = findViewById(R.id.tvBudget);
        tvSpent       = findViewById(R.id.tvSpent);
        btnAddExpense  = findViewById(R.id.btnAddExpense);
        btnSetBudget   = findViewById(R.id.btnSetBudget);
        btnReports     = findViewById(R.id.btnReports);
        btnLogout      = findViewById(R.id.btnLogout);
        lvExpenses     = findViewById(R.id.lvExpenses);

        loadDashboard();

        btnAddExpense.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddExpenseActivity.class);
            intent.putExtra("userId", currentUserId);
            startActivity(intent);
        });

        btnSetBudget.setOnClickListener(v -> showSetBudgetDialog());

        btnReports.setOnClickListener(v -> {
            Intent intent = new Intent(this, ReportsActivity.class);
            intent.putExtra("userId", currentUserId);
            startActivity(intent);
        });

        btnLogout.setOnClickListener(v -> {
            prefs.edit()
                    .putBoolean("isLoggedIn", false)
                    .putInt("userId", -1)
                    .apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboard();
    }

    private void loadDashboard() {
        double budget  = db.getBudget(currentUserId);
        double spent   = db.getTotalExpenses(currentUserId);
        double balance = budget - spent;

        tvBudget.setText("Budget: ₹" + String.format("%.0f", budget));
        tvSpent.setText("Spent: ₹" + String.format("%.0f", spent));
        tvBalance.setText("₹" + String.format("%.0f", balance));

        if (budget > 0 && spent > budget) {
            Toast.makeText(this, "⚠ Budget Exceeded!", Toast.LENGTH_LONG).show();
        }

        List<Expense> expenses = db.getAllExpenses(currentUserId);
        List<String> displayList = new ArrayList<>();
        for (Expense e : expenses) {
            displayList.add(e.getCategory() + " — ₹"
                    + e.getAmount() + "  (" + e.getDate() + ")"+e.getNote());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, displayList);
        lvExpenses.setAdapter(adapter);
    }

    private void showSetBudgetDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Monthly Budget");
        final EditText input = new EditText(this);
        input.setHint("Enter amount in ₹");
        input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        builder.setView(input);
        builder.setPositiveButton("Save", (dialog, which) -> {
            String val = input.getText().toString().trim();
            if (!val.isEmpty()) {
                db.setBudget(Double.parseDouble(val), currentUserId);
                Toast.makeText(this, "Budget set!", Toast.LENGTH_SHORT).show();
                loadDashboard();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
}